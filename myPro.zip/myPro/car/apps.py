from django.apps import AppConfig


class CarConfig(AppConfig):
    name = 'car'
